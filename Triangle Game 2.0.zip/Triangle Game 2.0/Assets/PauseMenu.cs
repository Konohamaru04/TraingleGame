﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public GameObject pauseUI;
    private bool paused = false;

    void start()
    {
        pauseUI.SetActive(false);   
    }

    void update()
    {
        if(Input.GetButtonDown("Pause"))
        {
            paused = !paused;
        }

        if(paused)
        {
            pauseUI.SetActive(true);
            Time.timeScale = 0;
        }

        if(!paused)
        {
            pauseUI.SetActive(false);
            Time.timeScale = 1;
        }
    }
}
